
from mpi4py import MPI
from petsc4py import PETSc
import numpy as np
from basix.ufl import element, mixed_element
from dolfinx import default_real_type, fem, io, mesh,plot,la
import ufl
import matplotlib.pyplot as plt    # Plotting Library
from dolfinx.io import XDMFFile
import h5py
import pyvista
from petsc4py import PETSc
import sys
from dolfinx.mesh import create_unit_square
from math import pi
from dolfinx.mesh import locate_entities, meshtags
from dolfinx.fem import functionspace, Function, locate_dofs_geometrical, dirichletbc, Constant
from dolfinx.fem.petsc import LinearProblem
from petsc4py.PETSc import ScalarType

#Initialize MPI
comm = MPI.COMM_WORLD

# Load the mesh from the XDMF file
with io.XDMFFile(MPI.COMM_WORLD, "Circle_hole_small.xdmf", "r") as xdmf:
    msh = xdmf.read_mesh(name ='mesh')
    #write function to file
with io.XDMFFile(comm,'Circle_hole_small.xdmf','w') as ofile:
    ofile.write_mesh(msh)
    encoding=io.XDMFFile.Encoding.HDF5

    # Open the HDF5 file for reading
with h5py.File("Circle_hole_small.h5", "r") as ifile:
    # Read the mesh dataset from HDF5
    mesh_dataset = ifile["/Mesh"]

# Define measures
dx = ufl.Measure("dx", domain=msh)


#P_u = element("Lagrange", msh.basix_cell(), 1, shape=(msh.topology.dim, ))
#P_p = element("Lagrange", msh.basix_cell(), 1)
p_u = element("Lagrange", msh.topology.cell_name(), 1, shape=(msh.topology.dim, ),dtype=default_real_type )
p_p = element("Lagrange", msh.topology.cell_name(), 1, dtype=default_real_type)
W_elem = mixed_element([p_u, p_p])

# Create mixed function space

W = fem.functionspace(msh, W_elem)
# Define trial and test functions
(u, p) = ufl.TrialFunctions(W)
(q, v) = ufl.TestFunctions(W)

# Print shape of the trial function and its gradient
print(f"Shape of u: {u.ufl_shape}")
print(f"Shape of grad(u): {ufl.grad(u).ufl_shape}")
##############################################################################
#Define Dirichlet boundary conditions
def outer_boundary(x):
    r = np.sqrt(x[0]**2 + x[1]**2)
    return np.isclose(r, 1.0)

def inner_boundary(x):
    r = np.sqrt(x[0]**2 + x[1]**2)
    return np.isclose(r, 0.001)
# Locate boundary facets
fdim = msh.topology.dim - 1
outer_facets = mesh.locate_entities_boundary(msh, fdim, outer_boundary)
inner_facets = mesh.locate_entities_boundary(msh, fdim, inner_boundary)





# Concatenate and sort the arrays based on facet indices. outer facets marked with 1, inner facets with two
marked_facets = np.hstack([outer_facets, inner_facets])
marked_values = np.hstack([np.full_like(outer_facets, 10), np.full_like(inner_facets, 20)])
sorted_facets = np.argsort(marked_facets)
facet_tag = mesh.meshtags(msh, fdim, marked_facets[sorted_facets], marked_values[sorted_facets])

ds = ufl.Measure("ds", domain=msh, subdomain_data=facet_tag)

#W.sub(0) --> displacement and W.sub(1) --> pressure 
W0 = W.sub(0)
Q0, _ = W0.collapse()
u_bc = Function(Q0)
u_bc.x.array[:] = 0

W1 = W.sub(1)
Q1, _ = W1.collapse()
p_bc = Function(Q1)
p_bc.x.array[:] = 0

dofs_u = fem.locate_dofs_topological((W0,Q0), fdim, outer_facets)
dofs_p = fem.locate_dofs_topological((W1,Q1), fdim, outer_facets)
outer_boundary_displacement = (fem.dirichletbc(u_bc, dofs_u, (W0)))
outer_boundary_pressure = (fem.dirichletbc(p_bc, dofs_p, (W1)))
bcs = [outer_boundary_displacement ,outer_boundary_pressure ]


print("Boundary conditions applied successfully.")

# Define material properties
E =  0.770
nu =  0.4 / 1.4
G = (E / (2 * (1 + nu)))
λ = E * nu / ((1.0 + nu) * (1.0 - 2.0 * nu))
##############################################################################
# Define strain and stress
def epsilon(u):
    E = ufl.sym(ufl.grad(u))
    return E

def sigma(u, p):
    
    """Return an expression for the stress σ given a displacement field"""
    S = 2.0 * G * ufl.sym(ufl.grad(u)) + λ * ufl.tr(ufl.sym(ufl.grad(u))) * ufl.Identity(len(u)) - p * ufl.Identity(len(u))
    return S


# Compute stress tensor
Stress = sigma(u, p)
# Momentum balance
B = Constant(msh, PETSc.ScalarType((0, 0)))
T = Constant(msh, PETSc.ScalarType(0))
n = ufl.FacetNormal(msh)
Tr = T *n

a1 = (ufl.inner(Stress, ufl.grad(q)) * dx)
L1 = (ufl.inner(B, q) * dx)

# Add L of fluid problem
f = Constant(msh,0.0)
k = Constant(msh,1.0)
pressure_drop = 0.33
r1 = 0.001
r2 = 1.0
g1 = Constant(msh, -pressure_drop / (r1 * (np.log(r1) - np.log(r2))))  # g1 --> inner boundary (3)
A1 = 2.0 * np.pi * 0.001
A2 = 2.0 * np.pi * 1.0
g2 = -g1 * (A1 / A2)  # g2 --> outer boundary (2)
a2 = k * ufl.inner(ufl.grad(p), ufl.grad(v)) * dx
L2 = f * v * dx + g1 * v * ds(20)

# State full problem
a = a1 + a2
L = L1 + L2

# Solve variational problem
w_coupled = fem.Function(W)

problem = fem.petsc.LinearProblem(a, L, bcs, w_coupled, petsc_options={"ksp_type": "preonly", "pc_type": "lu"})
w_coupled = problem.solve()
(u, p) = w_coupled.split()

# Write the solution to an XDMF file
u.name = "displacement"
p.name = "pressure"
with XDMFFile(MPI.COMM_WORLD, "displacement.xdmf", "w") as file:
    file.write_mesh(msh)
    file.write_function(u)
    
with XDMFFile(MPI.COMM_WORLD, "pressure.xdmf", "w") as file:
    file.write_mesh(msh)
    file.write_function(p)   


# Compute velocity field
elements = element("Lagrange", msh.basix_cell(), 1, shape=(msh.topology.dim, ))
V = fem.functionspace(msh, elements)
w = Function(V)
w_expr = fem.Expression((-k * ufl.grad(p)), V.element.interpolation_points())
w.interpolate(w_expr)
w.name = "velocity"

# Write the velocity field to an XDMF file
with XDMFFile(MPI.COMM_WORLD, "velocity.xdmf", "w") as file:
    file.write_mesh(msh)
    file.write_function(w)

# Curve plot
import numpy as np
import matplotlib.pyplot as plt
tol = 0.001  # avoid hitting points outside the domain
#x = np.linspace(0.5 + tol, 3.0 - tol, 100)
x = np.linspace(0.001 + tol, 1.0 - tol, 1000)
points = [(x_,0) for x_ in x]  # 2D points
print (points)
#points
#u_line = np.array([sqrt(u(point)[0]**2+u(point)[1]**2) for point in points])
# Ensure that the points are within the domain
p_line = np.array([p(point) for point in points])
print(p_line)
plt.title("Numerical solutions") 
plt.xlabel("Radius") 
#plt.plot(x, u_line, 'b', linewidth=2)  
plt.plot(x, p_line, 'k--', linewidth=2)
plt.grid(True)
#pyplot.xscale('log')
#plt.xlabel('$x$')
#plt.legend(['Deformation ', 'Pressure'], loc='upper right')
plt.legend(['Pressure'], loc='upper right')
#plt.show()

#Analytical solution
from matplotlib import pyplot
r_0 = 0.001
#r_0 = 0.85
r_max = 1.01
#r_0 = 0.5
#r_max = 3.01
r = np.arange(r_0,r_max,0.0001) 
Gamma = 0.4
q = 0.0478
#q = 0.1538
B1 = -(1-Gamma)*((q*(1+(1+Gamma)*np.log(r_0)))/(2*(((r_0)**2)*(1+Gamma)+(1-Gamma))))+((1+Gamma)/2)*q*np.log(r_0)
B2 = -(1-Gamma)*((q*(r_0)**2*(1+(1+Gamma)*np.log(r_0)))/(2*(((r_0)**2)*(1+Gamma)+(1-Gamma))))
u_analytic = (-q*r*np.log(r))/(2)+((2*B1+q)*r)/(2*(1+Gamma))+(B2)/((1-Gamma)*r)
#u_analytic = -(1/4)*con*r**2 + k1*np.log(r)+k2
plt.title("Analytical solutions") 
plt.xlabel("Radius") 
#plt.ylabel("Deformation") 
plt.plot(r,u_analytic, 'b', linewidth=2) 
plt.grid(True)
#pyplot.xscale('log')
#plt.ylim((0,0.06))
#sigma_r_analytical = -(1+Gamma)/(2)*q*np.log(r_0)+B1-B2/(r**2)
#plt.plot(r, sigma_r_analytical, 'k--', linewidth=2)
plt.legend(['Deformation '], loc='upper right')
#plt.show()
plt.title("Numerical and analytical solutions for deformation") 
plt.xlabel("Radius") 
plt.plot(x, u_line, 'b', linewidth=2)
plt.plot(r,u_analytic, 'r--', linewidth=2) 
plt.grid(True)
plt.legend(['Numerical ','Analytical'], loc='upper right')
plt.show()