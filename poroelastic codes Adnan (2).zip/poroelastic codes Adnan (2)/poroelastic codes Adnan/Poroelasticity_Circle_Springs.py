from dolfin import *
from ufl import nabla_div
import matplotlib.pyplot as plt
from matplotlib import pyplot
import fenics as fe
import matplotlib.pyplot as plt
import numpy as np
import ufl
import sys


#Read Mesh
mesh = Mesh('Circle_hole_small.xml')
subdomains = MeshFunction("size_t", mesh, "Circle_hole_small_physical_region.xml")
boundaries = MeshFunction("size_t", mesh, "Circle_hole_small_facet_region.xml")
# Write HDF5
hdf = HDF5File(mesh.mpi_comm(), "Circle_hole_small.h5", "w")
hdf.write(mesh, "/mesh")
hdf.write(subdomains, "/subdomains")
hdf.write(boundaries, "/boundaries")
mesh = Mesh()
hdf = HDF5File(mesh.mpi_comm(), "Circle_hole_small.h5", "r")
hdf.read(mesh, "/mesh", False)
sub_domains = MeshFunction("size_t", mesh, 1)    #--> 1 is dimension for curve
hdf.read(sub_domains, "/boundaries")
# Measures and integration points
boundaries = sub_domains
#dx = dx(metadata={'quadrature_degree': q_degree})
#ds = ds(subdomain_data=boundaries, metadata={'quadrature_degree': q_degree})
ds = ds(subdomain_data=boundaries)
#######################################################
#Function Spaces
P_u = VectorElement("Lagrange", mesh.ufl_cell(), 1)
P_p = FiniteElement("Lagrange", mesh.ufl_cell(), 1)
# Define the mixed element
W_elem = MixedElement([P_u, P_p])
# Define the mixed function space
W = FunctionSpace(mesh, W_elem)
#######################################################
#Boundary Conditions
# 2 --> outer boundary
# 3 --> inner boundary
#Define Dirichlet boundary conditions
#W.sub(0) --> displacement and W.sub(1) --> pressure 
inner_boundary_pressure = DirichletBC(W.sub(1), Constant((0.2)), boundaries, 3)
outer_boundary_pressure = DirichletBC(W.sub(1), Constant((0.0)), boundaries, 2)
bcs = [inner_boundary_pressure, outer_boundary_pressure]
######################################################
#Function for Second Piola Kirchhoff Stresses
def PK2(u,p): #Piola-Kirchhoff Stress
    d = len(u)
    I = Identity(d)                     # Identity tensor
    F = variable(I + grad(u))           # Deformation gradient

    
    C = variable(F.T*F)                 # Right Cauchy-Green tensor
   
    #E = variable(0.5*(C-I))
    
    # Invariants of deformation tensors
    Ic = variable(tr(C))
    J  = variable(det(F))
    I3 = variable(det(C))
        
    psi_skel = (lmbda/4)*(I3-1)-(mu+(lmbda/2))*ln(J)+(mu/2)*(Ic-3)   #macroscopic strain energy function of skeleton

    P = diff(psi_skel,F)		  #First Piola Kirchhoff stress	
    S = inv(F)*P - p*J*inv(C)         #Second Piola kirchhoff stresses
    return S


######################################################
#Plot Function of spring stiffness(penalty parameter) which is a function of displacement u
u_0 = 0.0
u_max = 2.0
location = np.arange(u_0,u_max,0.001) 

c1 = 15.0
c2 = 1.0

pen_val = 1e1
f = (pen_val)/(1+np.exp(-c1*(location-c2)))-(pen_val/2)
plt.title("spring stiffness") 
plt.xlabel("location") 
#plt.ylabel("Deformation") 
plt.plot(location,f, 'b', linewidth=2) 
plt.grid(True)
plt.ylim((0,pen_val/2))
plt.xlim((1.0,1.4))
plt.legend(['penalty parameter'], loc='upper left')
plt.show()
#####################################################
#Define Functions and Testfunctions
w_coupled = Function(W)      #current solution
#Split mixed functions
(u, p)= split(w_coupled)
(q, v) = TestFunctions(W)

# Kinematics
d = u.geometric_dimension()
I = Identity(d)             # Identity tensor
F = I + grad(u)             # Deformation gradient
C = F.T*F                   # Right Cauchy-Green tensor
# Invariants of deformation tensors
Ic = tr(C)
J  = det(F)
#######################################################
#Define Penalty parameter
class Penalty1(UserExpression):
    def __init__(self,u,c1,c2,pen_value, **kwargs):
        super().__init__(**kwargs)
        self.u = u
        self.c1 = c1
        self.c2 = c2
        self.pen_value = pen_value
    def eval(self, value, x):
        value[0] = self.pen_value/(1+exp(-self.c1*(sqrt(pow(x[0]+self.u[0](x),2)+pow(x[1]+self.u[1](x),2))-self.c2)))-(self.pen_value/3)
    def value_shape(self):
        return ( )

#Contact with nonlinear springs
c1 = 15.0
c2 = 1.0
#pen_value = 1e3
pen_value = 1e1
pen = Penalty1(u,c1,c2,pen_value,degree=5)
obstacle = Expression(("0.0","0.0"), degree=3)
#############################################################
#State problem by defining weak forms 
young_mod, nu = 0.770, 0.4/1.4    #nu = 0.2857    --> for g1 = Constant(-pressure_drop/(r1*(ln(r1)-ln(r2)))) 
mu, lmbda = Constant(young_mod/(2*(1 + nu))), Constant(young_mod*nu/((1 + nu)*(1 - 2*nu)))
bulk_mod = Constant(3/(young_mod*(1-2*nu)))

##stress tensor 
Stress = PK2(u,p)

##Momentum balance
Contact_contribution = (pen*dot(q, (u-obstacle)))*ds(2)
L1 = inner(F*Stress,grad(q))*dx + Contact_contribution


#Add weak form of fluid problem (first without Neumann BC terms)
##L = f*v*J*dx    and     a = k*inner(inv(F).T*grad(p), inv(F).T*grad(v))*J*dx
f = Constant(0.0)
k = Constant(1.0)
L2 = f*v*J*dx - k*inner(inv(F).T*grad(p), inv(F).T*grad(v))*J*dx

###Weak form of fluid problem (with Neumann BC terms)
#pressure_drop = 2.5
#r1 = 0.001
#r2 = 1.0
#g1 = Constant(-pressure_drop/(r1*(ln(r1)-ln(r2))))   
#A1 = 2.0*pi*r1
#A2 = 2.0*pi*r2
#g2 = -g1*(A1/A2)                #outer boundary (2)
###Nanson's formula to derive da_dA
#da_dA_n = J*(inv(F).T)*N
#da_dA = sqrt(dot(da_dA_n,da_dA_n))
#L2 = f*v*J*dx + g1*v*da_dA*ds(3) - k*inner(inv(F).T*grad(p), inv(F).T*grad(v))*J*dx
#L2 = f*v*J*dx + g1*v*da_dA*ds(3) + g2*v*da_dA*ds(2) - k*inner(inv(F).T*grad(p), inv(F).T*grad(v))*J*dx



#State full problem
F = L1 + L2 

#######################################################
#Solving (Remark: For solver settings for pure Neumann BC see below)
##Solve variational problem
w_trial = TrialFunction(W)
derivative_of_weak_form = derivative(F,w_coupled,w_trial)
my_problem = NonlinearVariationalProblem(F,w_coupled,bcs,derivative_of_weak_form)
my_solver = NonlinearVariationalSolver(my_problem)
stype = 'newton'
my_solver.parameters['nonlinear_solver']=stype
sprms = my_solver.parameters[stype+'_solver']
sprms["relative_tolerance"] = 1e-6;
#sprms['linear_solver'] = 'cg';
#sprms['preconditioner'] = 'ilu';
# Set maximum iterations:
sprms['maximum_iterations'] = 10
my_solver.solve()
#####################################################
##Visualisation
(u, p) = w_coupled.split()


plot(u, mode="displacement", title='Deformation')
plt.show()

plot(p, title='Pressure')
plt.show()

w = -k*grad(p)
plot(w, title='velocity')
plt.show()

#Compute the porosity depending on fluid and skeleton state
#p = bulk_mod*(-1/(1-phi_0)+(1/J_s))-eta*(1/(J*phi)-1/phi_0)
d = u.geometric_dimension()
I = Identity(d)             # Identity tensor
F = I + grad(u)             # Deformation gradient
J  = det(F)
phi_0 = 0.5    #initial porosity
eta = 0.01      #penalty parameter
phi = 1-bulk_mod/(J*(p+(bulk_mod/(1-phi_0))))
plot(phi, title='porosity')
plt.show()
#####################################################
#Save files

# Save solution in VTK format
file = File("Coupled_problem_displacement.pvd");
file << u;

file = File("Coupled_problem_pressure.pvd")
file << p

V_velocity = VectorFunctionSpace(mesh, "CG", degree = 1)
velocity = Function(V_velocity, name="velocity")
velocity.assign(project(w, V_velocity, solver_type="cg"))
file = File("Coupled_problem_velocity.pvd")
file << velocity


V_porosity = FunctionSpace(mesh, "CG",1)
porosity = project(phi, V_porosity, solver_type="cg")
file = File("Coupled_problem_porosity.pvd")
file << porosity
#################################################


##################################################
###Solver settings for pure Neumann BC (Nullspace,...)
"""
w_trial = TrialFunction(W)
J = derivative(F,w_coupled,w_trial)
nullspace_basis = w_coupled.vector().copy()
W.sub(0).dofmap().set(nullspace_basis, 1.0)
nullspace_basis.apply('insert')
nullspace = VectorSpaceBasis([nullspace_basis])
nullspace.orthonormalize()
###Set up the nonlinear problem
class PoroelasticityProblem(NonlinearProblem):
    def __init__(self, F, J, bcs, nullspace):
        NonlinearProblem.__init__(self)
        self.linear_form = F
        self.bilinear_form = J
        self.bcs = bcs
        self.nullspace = nullspace
    def F(self, b, x):
        assemble(self.linear_form, tensor=b)
        for bc in self.bcs:
            bc.apply(b, x)
        self.nullspace.orthogonalize(b)
    def J(self, A, x):
        assemble(self.bilinear_form, tensor=A)
        for bc in self.bcs:
            bc.apply(A)
        #as_backend_type(A).set_nullspace(self.nullspace)
        
NLProblem = PoroelasticityProblem(F,J,bcs,nullspace)

class CustomSolver(NewtonSolver):
    def __init__(self, mpi_comm, linear_solver, petsc_factory):
        NewtonSolver.__init__(self,
                mpi_comm,
                linear_solver,
                petsc_factory
        )

    def solver_setup(self, A, P, problem, iteration):
        #A.set_nullspace(problem.nullspace)
        as_backend_type(A).set_nullspace(problem.nullspace)
        self.linear_solver().set_operator(A)
        PETScOptions.set("ksp_type", "gmres")
        PETScOptions.set("pc_type", "ilu")
        PETScOptions.set("ksp_atol", 1.0e-10)
        PETScOptions.set("ksp_rtol", 1.0e-8)
        self.linear_solver().set_from_options()
        
###Set up the linear solver
linear_solver = PETScKrylovSolver("gmres")
ksp = linear_solver.ksp() # Handle for PETSc interaction
newton_solver = CustomSolver(mesh.mpi_comm(),linear_solver,PETScFactory.instance())
newton_solver.parameters["relative_tolerance"] = 1e-6
newton_solver.parameters["maximum_iterations"] = 10

newton_solver.solve(NLProblem, w_coupled.vector())
"""



